from setuptools import setup


setup( 

    name="UsuariosYcontraseñas",
    version="1.0",
    description="Usuarios y contraseñas para paginas o correos",
    author="Santiago",
    author_email="Fajarfsabo161@gmail.com",
    url="www.petstyle.com",
    packages=["contraseñasYusarios","contraseñasYusarios.usuariosYcontraseñas"]


)